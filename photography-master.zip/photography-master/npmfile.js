exports.printMsg = function() {
    console.log("Visit http://photography.ramswaroop.me for a treat!");
};